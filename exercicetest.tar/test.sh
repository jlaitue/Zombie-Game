#!/bin/sh
FILE=exercicetest.tar
FILES=files$$.txt
LIVRABLES="whoami.txt main.cpp"
COMP_LOG=compile$$.log

oups()
{
  echo "[OUPS] $0: $@"
  if [ -f $FILES ]; then rm $FILES; fi
  if [ -f $COMP_LOG ]; then rm $COMP_LOG; fi
  exit 1
}

if [ $# != 1 ]; then oups "Usage: $0 archive.tar"; fi
if [ $FILE != "$1" ]; then oups "$FILE attendu"; fi
test -f "$FILE"
if [ $? != 0 ]; then oups "$FILE n'est pas un fichier ordinaire!"; fi

tar tf "$FILE" > $FILES 2>&1
if [ $? != 0 ]; then oups "$FILE n'est pas une archive valide!"; fi
for F in $LIVRABLES
do
	grep "^$F\$" $FILES > /dev/null
	if [ $? != 0 ]; then oups "$FILE ne contient pas $F!!!"; fi
	tar xf $FILE $F > /dev/null 2>&1
	if [ $? != 0 ]; then oups "Extraction de $F impossible!"; fi
done
NUM=`grep "numero_etudiant:" whoami.txt | sed -e "s/[^0-9]//g"`
if [ "$NUM" == "" ]; then oups "$FILE mauvais numero d'etudiant..."; fi

CMD="g++ -Wall -o main main.cpp"
$CMD > $COMP_LOG 2>&1
if [ $? != 0 ]; then oups "La commande '$CMD' a produit echouee"; fi
if [ -s $COMP_LOG ]; then oups "La commande '$CMD' a produit des erreurs"; fi

CMD="./main"
$CMD
if [ $? != 0 ]; then oups "La commande '$CMD' a echouee"; fi

rm $FILES
rm $COMP_LOG
rm main
rm $LIVRABLES
echo $"-------------Etudiant $NUM : test ok"
exit 0
